﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using RPSite.Helpers;
using System.Web.Security;
using RPSite.BLL;
using RPSite.Model;

namespace RPSite.UserCenter
{
    public partial class BuyCredit : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Membership.GetUser() == null)
            {
                ShowMessage.Show("请先登录");
                return;
            }
            Guid userId = (Guid)Membership.GetUser().ProviderUserKey;
            RP_UserInfoBLL bll = new RP_UserInfoBLL();
            var userInfo = bll.GetByUserId(userId);

            this.litCredit.Text = Convert.ToString(userInfo.Credit);
        }

        protected void btnBuy_Click(object sender, EventArgs e)
        {
            RP_CreditOrder order = new RP_CreditOrder();
            order.CreditCount = Convert.ToInt32(txtBuyCount.Text);
            Guid userId = (Guid)Membership.GetUser().ProviderUserKey;
            order.UserId = userId;
            order.Status = "未支付";//订单初始状态为“未支付”

            //插入订单表
            RP_CreditOrderBLL orderBll = new RP_CreditOrderBLL();
            order = orderBll.Add(order);

            string miyao = "mk@2$z";
            double amount = Convert.ToInt32(txtBuyCount.Text)*0.1;//一个积分0.1元
            string partnerId = "1";
            string productName = txtBuyCount.Text + "个积分";
            string tradeNo = order.Id.ToString();//用订单表的id做订单号

            //为按顺序连接 总金额、 商户编号、订单号、商品名称、商户密钥的MD5值。
            string md5 = CommonHelper.GetMD5(amount.ToString("0.00") + partnerId + tradeNo + productName + miyao);

            string url = "http://www.zhifubao.com:8080/AliPay/PayGate.ashx?partner=" + partnerId + "&return_url=" + Server.UrlEncode("http://localhost:4171/UserCenter/BuyCreditCallback.aspx") + "&subject=" + Server.UrlEncode(productName) + "&body=" + productName + "&out_trade_no=" + tradeNo + "&total_fee=" + amount.ToString("0.00")
                + "&seller_email=abc@abc.com&sign=" + md5;

            Response.Redirect(url);
        }
    }
}